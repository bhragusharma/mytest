"""
DevOps Chatbot Frontend - Streamlit MVP
Clean UI with dual authentication and chat interface
"""

import streamlit as st
import requests
import json
from datetime import datetime
import base64
from pathlib import Path

# Configuration
BACKEND_URL = "http://localhost:8000"

# Page configuration
st.set_page_config(
    page_title="Commercehub Devops Chatbot",
    layout="wide",
    initial_sidebar_state="collapsed"
)

def load_css():
    """Load custom CSS for styling"""
    st.markdown("""
    <style>
    /* Main container styling with space for fixed header */
    .main .block-container {
        padding-top: 50px;
        padding-bottom: 2rem;
        color: black;
        max-height: calc(100vh - 50px);
        overflow-y: auto;
    }
    
    /* Hide Streamlit header and footer */
    header[data-testid="stHeader"] {
        display: none;
    }
    
    .stApp > footer {
        display: none;
    }
    
    /* Ensure full height usage */
    .stApp {
        height: 100vh;
    }
    
    /* Fixed header styling */
    .fixed-header {
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        background-color: white;
        border-bottom: 2px solid #e0e0e0;
        padding: 8px 20px;
        z-index: 999;
        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }
    
    .header-content {
        display: flex;
        justify-content: space-between;
        align-items: center;
        max-width: 1200px;
        margin: 0 auto;
    }
    
    .header-title {
        font-size: 2.5rem;
        font-weight: bold;
        color: orange !important;
        margin: 0;
    }
    
    .header-user-info {
        display: flex;
        align-items: center;
        gap: 15px;
        color: black;
    }
    
    /* Hide sidebar but show logout button in header */
    .stSidebar {
        display: none;
    }
    
    .stSidebar .stButton {
        position: fixed !important;
        top: 20px !important;
        right: 20px !important;
        z-index: 1001 !important;
        display: block !important;
    }
    
    .stSidebar .stButton > button {
        background-color: #ff4444 !important;
        color: white !important;
        border: none !important;
        padding: 8px 16px !important;
        border-radius: 5px !important;
        font-size: 14px !important;
        height: auto !important;
        margin: 0 !important;
        display: block !important;
    }
    
    .stSidebar .stButton > button:hover {
        background-color: #ff3333 !important;
    }
    
    /* Scrollable chat content */
    .chat-container {
        position: relative;
        height: calc(100vh - 140px);
        overflow-y: auto;
        padding: 10px 0;
        scroll-behavior: smooth;
}

    
    /* Style the scrollbar */
    .chat-container::-webkit-scrollbar {
        width: 8px;
    }
    
    .chat-container::-webkit-scrollbar-track {
        background: #f1f1f1;
        border-radius: 4px;
    }
    
    .chat-container::-webkit-scrollbar-thumb {
        background: #c1c1c1;
        border-radius: 4px;
    }
    
    .chat-container::-webkit-scrollbar-thumb:hover {
        background: #a1a1a1;
    }
    

    
    /* Message input container styling */
    .message-input-container {
        position: fixed;
        left: 0;
        right: 0;
        bottom: 0;
        background-color: white;
        padding: 10px 20px;
        border-top: 1px solid #e0e0e0;
        z-index: 1000;
}

    
    /* Ensure text area is properly styled */
    .message-input-container .stTextArea textarea {
        background-color: #f9f9f9 !important;
        border: 1px solid #ddd !important;
        border-radius: 8px !important;
    }
    
    /* Chat message styling */
    .user-message {
        background-color: #e3f2fd;
        padding: 12px;
        border-radius: 15px;
        margin: 8px 0;
        border-left: 4px solid #2196f3;
        color: black;
    }
    
    .bot-message {
        background-color: #f5f5f5;
        padding: 12px;
        border-radius: 15px;
        margin: 8px 0;
        border-left: 4px solid #4caf50;
        color: black;
    }
    
    .agent-info {
        background-color: #e8f4f8;
        padding: 8px 12px;
        border-radius: 10px;
        margin: 4px 0;
        border-left: 3px solid #2196f3;
        font-size: 0.9em;
        color: #555;
    }
    
    .suggestions-container {
        background-color: #fff3e0;
        padding: 12px;
        border-radius: 10px;
        margin: 8px 0;
        border-left: 3px solid #ff9800;
        color: black;
    }
    
    .suggestions-container .stButton {
        margin: 4px 2px;
        display: inline-block;
    }
    
    .suggestions-container .stButton > button {
        background-color: #fff !important;
        color: #ff9800 !important;
        border: 1px solid #ff9800 !important;
        border-radius: 20px !important;
        padding: 6px 12px !important;
        font-size: 0.85em !important;
        height: auto !important;
        transition: all 0.3s !important;
    }
    
    .suggestions-container .stButton > button:hover {
        background-color: #ff9800 !important;
        color: white !important;
    }
    
    /* Plain white background with black text */
    .stApp {
        background-color: white;
        color: black;
    }
    
    /* Ensure all text is black */
    .stMarkdown, .stText, h1, h2, h3, h4, h5, h6, p, div, span {
        color: black !important;
    }
    
    /* Larger font for title */
    .title-large h3 {
        font-size: 2.5rem !important;
        font-weight: bold !important;
        color: orange !important;
        margin-bottom: 1.5rem !important;
    }
    
    /* Gray shaded input boxes */
    .stTextInput > div > div > input {
        height: 35px;
        font-size: 14px;
        color: black;
        background-color: #f5f5f5 !important;
        border: 1px solid #ddd !important;
    }
    
    /* Remove black background from password eye icon - more specific selectors */
    .stTextInput button[kind="secondary"] {
        background-color: transparent !important;
        border: none !important;
        color: #666 !important;
    }
    
    .stTextInput button[kind="secondary"]:hover {
        background-color: #f0f0f0 !important;
    }
    
    /* Alternative selector for eye icon */
    .stTextInput div[data-testid="baseButton-secondary"] {
        background-color: transparent !important;
        border: none !important;
    }
    
    .stTextInput div[data-testid="baseButton-secondary"] button {
        background-color: transparent !important;
        border: none !important;
        color: #666 !important;
    }
    
    /* Hide character count */
    .stTextInput > div > div > div[data-testid="InputInstructions"] {
        display: none !important;
    }
    
    /* Radio button text */
    .stRadio > div > label {
        color: black !important;
    }
    
    /* Orange background login button aligned to left */
    .login-button .stButton > button {
        background-color: #ff8c00 !important;
        color: white !important;
        border: none !important;
        border-radius: 5px;
        transition: all 0.3s;
        height: 35px;
        width: 120px;
        margin-left: 0;
    }
    
    .login-button .stButton > button:hover {
        background-color: #ff7700 !important;
    }
    
    /* Regular button styling for other buttons */
    .stButton > button {
        background-color: #2196f3;
        color: white;
        border: none;
        border-radius: 5px;
        transition: background-color 0.3s;
        height: 35px;
    }
    
    .stButton > button:hover {
        background-color: #1976d2;
    }
    
    /* Radio button styling */
    .stRadio > div {
        margin-bottom: 1rem;
    }
    
    /* Force override for login button - multiple selectors */
    div.login-button button[kind="primary"] {
        background-color: #ff8c00 !important;
        color: white !important;
        border: none !important;
    }
    
    div.login-button button[kind="primary"]:hover {
        background-color: #ff7700 !important;
    }
    
    /* Additional override for eye icon */
    .stTextInput .st-emotion-cache-1erivf3 {
        background-color: transparent !important;
    }
    
    .stTextInput button {
        background: transparent !important;
        border: none !important;
    }
    </style>
    """, unsafe_allow_html=True)

def initialize_session_state():
    """Initialize session state variables"""
    if 'authenticated' not in st.session_state:
        st.session_state.authenticated = False
    if 'token' not in st.session_state:
        st.session_state.token = None
    if 'user_info' not in st.session_state:
        st.session_state.user_info = None
    if 'messages' not in st.session_state:
        st.session_state.messages = []

def make_api_request(endpoint, data, method="POST"):
    """Make API request to backend"""
    try:
        url = f"{BACKEND_URL}{endpoint}"
        if method == "POST":
            response = requests.post(url, json=data, timeout=30)
        else:
            response = requests.get(url, timeout=30)
        
        return response.json(), response.status_code
    except requests.exceptions.RequestException as e:
        st.error(f"Connection error: {e}")
        return None, 500

def authenticate_user(auth_method, credentials):
    """Authenticate user with backend"""
    if auth_method == "Username & Password":
        endpoint = "/api/v1/auth/login"
        data = {
            "username": credentials["username"],
            "password": credentials["password"]
        }
    else:  # API Key & Secret
        endpoint = "/api/v1/auth/api-login"
        data = {
            "api_key": credentials["api_key"],
            "api_secret": credentials["api_secret"]
        }
    
    result, status_code = make_api_request(endpoint, data)
    
    # Check status code first
    if status_code == 200 and result and result.get("success"):
        st.session_state.authenticated = True
        st.session_state.token = result.get("token")
        st.session_state.user_info = result.get("user_info")
        return True, result.get("message", "Login successful")
    elif status_code == 401:
        # Authentication failed
        error_msg = result.get("detail", "Invalid username or password") if result else "Invalid credentials"
        return False, error_msg
    else:
        # Other errors
        error_msg = result.get("detail", "Authentication failed") if result else "Connection error"
        return False, error_msg

def send_chat_message(message):
    """Send message to chatbot backend"""
    data = {
        "message": message,
        "token": st.session_state.token
    }
    
    result, status_code = make_api_request("/api/v1/chat/message", data)
    
    if result and result.get("success"):
        # Return full result for enhanced features
        return {
            "response": result.get("response", "No response received"),
            "suggestions": result.get("suggestions", []),
            "agent": result.get("agent", "unknown"),
            "approach": result.get("approach", "basic"),
            "tools_used": result.get("tools_used", [])
        }
    else:
        return {
            "response": "Error: Unable to get response from chatbot",
            "suggestions": [],
            "agent": "error",
            "approach": "error",
            "tools_used": []
        }

def render_login_screen():
    """Render the login interface"""
    # Center the login form
    col1, col2, col3 = st.columns([1, 2, 1])
    
    with col2:
        # Title with larger font
        st.markdown('<div class="title-large"><h3>Identify yourself !!</h3></div>', unsafe_allow_html=True)
        
        # Authentication method selection
        auth_method = st.radio(
            "Choose authentication method:",
            ["Username & Password", "API Key & Secret"],
            key="auth_method"
        )
        
        # Login form
        with st.form("login_form"):
            if auth_method == "Username & Password":
                username = st.text_input("Username", placeholder="Enter username")
                password = st.text_input("Password", type="password", placeholder="Enter password")
                credentials = {"username": username, "password": password}
                required_fields = [username, password]
            else:
                api_key = st.text_input("API Key", placeholder="Enter API key")
                api_secret = st.text_input("API Secret", type="password", placeholder="Enter API secret")
                credentials = {"api_key": api_key, "api_secret": api_secret}
                required_fields = [api_key, api_secret]
            
            # Create a container for the login button with custom styling
            st.markdown('<div class="login-button">', unsafe_allow_html=True)
            login_button = st.form_submit_button("Login")
            st.markdown('</div>', unsafe_allow_html=True)
            
            if login_button:
                if all(required_fields):
                    with st.spinner("Authenticating..."):
                        success, message = authenticate_user(auth_method, credentials)
                    
                    if success:
                        st.success(message)
                        st.rerun()
                    else:
                        st.error(message)
                else:
                    st.error("Please fill in all fields")

def render_chat_interface():
    """Render the chat interface"""
    user_display = st.session_state.user_info.get("username", "User")
    
    # Create fixed header
    header_html = f"""
    <div class="fixed-header">
        <div class="header-content">
            <div class="header-title">🤖 Commercehub Devops Chatbot</div>
            <div class="header-user-info">
                <span>👤 {user_display}</span>
            </div>
        </div>
    </div>
    """
    
    st.markdown(header_html, unsafe_allow_html=True)
    
    # Put logout in sidebar and position it with CSS
    with st.sidebar:
        if st.button("🚪 Logout", key="sidebar_logout"):
            st.session_state.authenticated = False
            st.session_state.token = None
            st.session_state.user_info = None
            st.session_state.messages = []
            st.rerun()
    
    # Scrollable chat content container
    st.markdown('<div class="chat-container" style="padding-top: 10px;>', unsafe_allow_html=True)
    
    # Chat history
    st.markdown("### Chat History")
    
    if st.session_state.messages:
        for msg in st.session_state.messages:
            # User message
            st.markdown(
                f'<div class="user-message">'
                f'<strong>👤 You:</strong> {msg["user"]}'
                f'</div>',
                unsafe_allow_html=True
            )
            
            # Bot response
            bot_response = msg["bot"]
            if isinstance(bot_response, dict):
                response_text = bot_response.get("response", "No response")
                agent_info = bot_response.get("agent", "")
                approach = bot_response.get("approach", "")
                tools_used = bot_response.get("tools_used", [])
                suggestions = bot_response.get("suggestions", [])
                
                # Main response
                st.markdown(
                    f'<div class="bot-message">'
                    f'<strong>🤖 DevOps Bot:</strong> {response_text}'
                    f'</div>',
                    unsafe_allow_html=True
                )
                
                # Agent info (if available)
                if agent_info or approach or tools_used:
                    info_parts = []
                    if approach and approach != "basic":
                        info_parts.append(f"Approach: {approach}")
                    if tools_used:
                        info_parts.append(f"Tools: {', '.join(tools_used)}")
                    if agent_info:
                        info_parts.append(f"Agent: {agent_info}")
                    
                    if info_parts:
                        st.markdown(
                            f'<div class="agent-info">'
                            f'<small>ℹ️ {" | ".join(info_parts)}</small>'
                            f'</div>',
                            unsafe_allow_html=True
                        )
                
                # Suggestions (if available)
                if suggestions:
                    st.markdown(
                        '<div class="suggestions-container">'
                        '<strong>💡 Related Actions You Can Try:</strong>'
                        '</div>',
                        unsafe_allow_html=True
                    )
                    
                    for suggestion in suggestions:
                        if st.button(suggestion, key=f"suggestion_{msg['timestamp']}_{suggestion[:20]}"):
                            # Add suggestion as new message
                            st.session_state.messages.append({
                                "user": suggestion,
                                "bot": {"response": "Processing your suggestion...", "suggestions": []},
                                "timestamp": datetime.now().strftime("%H:%M:%S")
                            })
                            st.rerun()
            else:
                # Legacy format - just text
                st.markdown(
                    f'<div class="bot-message">'
                    f'<strong>🤖 DevOps Bot:</strong> {bot_response}'
                    f'</div>',
                    unsafe_allow_html=True
                )
    else:
        st.info("Start a conversation by typing a message below.")
    
    # Message input - positioned at bottom
    st.markdown('<div class="message-input-container">', unsafe_allow_html=True)
    st.markdown("### Send a Message")
    
    with st.form("message_form", clear_on_submit=True):
        message = st.text_area(
            "Type your question here...",
            placeholder="Ask me about deployments, monitoring, infrastructure, etc.",
            height=100
        )
        send_button = st.form_submit_button("Send", use_container_width=True)
        
        if send_button and message.strip():
            with st.spinner("🤖 Processing your request..."):
                response = send_chat_message(message.strip())
            
            # Add to message history
            st.session_state.messages.append({
                "user": message.strip(),
                "bot": response,
                "timestamp": datetime.now().strftime("%H:%M:%S")
            })
            
            st.rerun()
    
    st.markdown('</div>', unsafe_allow_html=True)  # Close message-input-container
    
    # Close chat container
    st.markdown('</div>', unsafe_allow_html=True)

def main():
    """Main application"""
    # Load custom CSS
    load_css()
    
    # Initialize session state
    initialize_session_state()
    
    # Route based on authentication status
    if not st.session_state.authenticated:
        render_login_screen()
    else:
        render_chat_interface()

if __name__ == "__main__":
    main()