"""
Redis Memory Manager
Handles conversation memory with TTL for user sessions
"""

import redis
import json
import os
from typing import Dict, Any, List, Optional
from datetime import datetime, timedelta
import logging

logger = logging.getLogger(__name__)

class RedisMemoryManager:
    """Manages conversation memory using Redis with TTL"""
    
    def __init__(self):
        # Load Redis configuration from environment (from AWS secrets)
        self.redis_host = os.getenv("REDIS_HOST", "localhost")
        self.redis_port = int(os.getenv("REDIS_PORT", "6379"))
        self.redis_password = os.getenv("REDIS_PASSWORD")
        self.redis_db = int(os.getenv("REDIS_DB", "0"))
        self.ttl_days = int(os.getenv("CONVERSATION_TTL_DAYS", "3"))
        
        # Initialize Redis connection
        self.redis_client = None
        self._connect()
    
    def _connect(self):
        """Establish Redis connection"""
        try:
            self.redis_client = redis.Redis(
                host=self.redis_host,
                port=self.redis_port,
                password=self.redis_password,
                db=self.redis_db,
                decode_responses=True,
                socket_connect_timeout=5,
                socket_timeout=5
            )
            
            # Test connection
            self.redis_client.ping()
            logger.info(f"Connected to Redis at {self.redis_host}:{self.redis_port}")
            
        except Exception as e:
            logger.error(f"Failed to connect to Redis: {e}")
            self.redis_client = None
    
    def _get_user_key(self, user_id: str) -> str:
        """Generate Redis key for user conversations"""
        return f"conversation:{user_id}"
    
    def _get_session_key(self, user_id: str, session_id: str = "default") -> str:
        """Generate Redis key for specific session"""
        return f"session:{user_id}:{session_id}"
    
    async def store_message(self, user_id: str, message: Dict[str, Any], session_id: str = "default") -> bool:
        """Store a conversation message"""
        if not self.redis_client:
            logger.warning("Redis not available, skipping message storage")
            return False
        
        try:
            # Add timestamp if not present
            if "timestamp" not in message:
                message["timestamp"] = datetime.utcnow().isoformat()
            
            # Store in conversation history
            conversation_key = self._get_user_key(user_id)
            message_json = json.dumps(message)
            
            # Add to list and set TTL
            self.redis_client.lpush(conversation_key, message_json)
            self.redis_client.expire(conversation_key, timedelta(days=self.ttl_days))
            
            # Also store in session-specific key
            session_key = self._get_session_key(user_id, session_id)
            self.redis_client.lpush(session_key, message_json)
            self.redis_client.expire(session_key, timedelta(days=self.ttl_days))
            
            # Limit conversation history (keep last 100 messages)
            self.redis_client.ltrim(conversation_key, 0, 99)
            self.redis_client.ltrim(session_key, 0, 99)
            
            logger.debug(f"Stored message for user {user_id}")
            return True
            
        except Exception as e:
            logger.error(f"Error storing message: {e}")
            return False
    
    async def get_conversation_history(self, user_id: str, limit: int = 20, session_id: str = None) -> List[Dict[str, Any]]:
        """Retrieve conversation history for a user"""
        if not self.redis_client:
            return []
        
        try:
            # Choose key based on session_id
            if session_id:
                key = self._get_session_key(user_id, session_id)
            else:
                key = self._get_user_key(user_id)
            
            # Get messages (most recent first)
            messages = self.redis_client.lrange(key, 0, limit - 1)
            
            # Parse and return (reverse to get chronological order)
            conversation = []
            for msg_json in reversed(messages):
                try:
                    message = json.loads(msg_json)
                    conversation.append(message)
                except json.JSONDecodeError:
                    logger.warning(f"Failed to parse message: {msg_json}")
                    continue
            
            logger.debug(f"Retrieved {len(conversation)} messages for user {user_id}")
            return conversation
            
        except Exception as e:
            logger.error(f"Error retrieving conversation: {e}")
            return []
    
    async def get_recent_context(self, user_id: str, context_window: int = 5) -> Dict[str, Any]:
        """Get recent conversation context for better understanding"""
        conversation = await self.get_conversation_history(user_id, limit=context_window)
        
        if not conversation:
            return {"has_context": False, "messages": []}
        
        # Extract relevant context
        context = {
            "has_context": True,
            "messages": conversation,
            "last_topics": self._extract_topics(conversation),
            "user_preferences": self._extract_preferences(conversation),
            "recent_agents_used": self._extract_agents_used(conversation)
        }
        
        return context
    
    def _extract_topics(self, conversation: List[Dict[str, Any]]) -> List[str]:
        """Extract topics from recent conversation"""
        topics = set()
        
        for message in conversation[-3:]:  # Last 3 messages
            user_input = message.get("user_input", "").lower()
            
            # AWS services
            if any(term in user_input for term in ["secret", "secrets", "aws"]):
                topics.add("aws_secrets")
            if any(term in user_input for term in ["deploy", "deployment", "ecs"]):
                topics.add("deployment")
            if any(term in user_input for term in ["docker", "container"]):
                topics.add("containers")
            if any(term in user_input for term in ["pipeline", "ci/cd"]):
                topics.add("cicd")
        
        return list(topics)
    
    def _extract_preferences(self, conversation: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Extract user preferences from conversation"""
        preferences = {
            "preferred_approach": "react",  # Default
            "detail_level": "medium",
            "includes_suggestions": True
        }
        
        # Analyze recent interactions
        for message in conversation[-5:]:
            response = message.get("response", {})
            if isinstance(response, dict):
                approach = response.get("approach")
                if approach:
                    preferences["preferred_approach"] = approach
        
        return preferences
    
    def _extract_agents_used(self, conversation: List[Dict[str, Any]]) -> List[str]:
        """Extract which agents were recently used"""
        agents = set()
        
        for message in conversation[-5:]:
            response = message.get("response", {})
            if isinstance(response, dict):
                agent = response.get("agent")
                if agent:
                    agents.add(agent)
        
        return list(agents)
    
    async def clear_user_memory(self, user_id: str) -> bool:
        """Clear all conversation memory for a user"""
        if not self.redis_client:
            return False
        
        try:
            # Delete conversation and session keys
            pattern = f"*:{user_id}*"
            keys = self.redis_client.keys(pattern)
            
            if keys:
                self.redis_client.delete(*keys)
                logger.info(f"Cleared memory for user {user_id}")
            
            return True
            
        except Exception as e:
            logger.error(f"Error clearing user memory: {e}")
            return False
    
    async def get_memory_stats(self, user_id: str) -> Dict[str, Any]:
        """Get memory statistics for a user"""
        if not self.redis_client:
            return {"available": False}
        
        try:
            conversation_key = self._get_user_key(user_id)
            message_count = self.redis_client.llen(conversation_key)
            ttl = self.redis_client.ttl(conversation_key)
            
            return {
                "available": True,
                "message_count": message_count,
                "ttl_seconds": ttl,
                "expires_in_days": round(ttl / 86400, 1) if ttl > 0 else 0
            }
            
        except Exception as e:
            logger.error(f"Error getting memory stats: {e}")
            return {"available": False, "error": str(e)}
    
    def is_available(self) -> bool:
        """Check if Redis is available"""
        if not self.redis_client:
            return False
        
        try:
            self.redis_client.ping()
            return True
        except:
            return False