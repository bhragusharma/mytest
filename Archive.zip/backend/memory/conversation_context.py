"""
Conversation Context Manager
Handles context building and management for enhanced conversations
"""

from typing import Dict, Any, List, Optional
from memory.redis_memory import RedisMemoryManager
import logging

logger = logging.getLogger(__name__)

class ConversationContext:
    """Manages conversation context and memory integration"""
    
    def __init__(self, memory_manager: RedisMemoryManager):
        self.memory = memory_manager
    
    async def build_context(self, user_id: str, current_message: str, session_id: str = "default") -> Dict[str, Any]:
        """Build comprehensive context for the current conversation"""
        
        # Get recent conversation history
        recent_context = await self.memory.get_recent_context(user_id, context_window=5)
        
        # Analyze current message for context clues
        current_analysis = self._analyze_current_message(current_message)
        
        # Build enhanced context
        context = {
            "user_id": user_id,
            "session_id": session_id,
            "current_message": current_message,
            "current_analysis": current_analysis,
            "memory_available": recent_context.get("has_context", False),
            "conversation_history": recent_context.get("messages", []),
            "recent_topics": recent_context.get("last_topics", []),
            "user_preferences": recent_context.get("user_preferences", {}),
            "recent_agents": recent_context.get("recent_agents_used", []),
            "context_suggestions": self._generate_context_suggestions(recent_context, current_analysis)
        }
        
        return context
    
    def _analyze_current_message(self, message: str) -> Dict[str, Any]:
        """Analyze the current message for context clues"""
        message_lower = message.lower()
        
        analysis = {
            "message_type": "query",
            "topics": [],
            "entities": [],
            "intent": "general",
            "complexity": "simple",
            "references_previous": False
        }
        
        # Detect message type
        if any(word in message_lower for word in ["find", "search", "list", "show"]):
            analysis["message_type"] = "search"
        elif any(word in message_lower for word in ["deploy", "restart", "force"]):
            analysis["message_type"] = "action"
        elif any(word in message_lower for word in ["how", "what", "why", "explain"]):
            analysis["message_type"] = "question"
        elif any(word in message_lower for word in ["setup", "configure", "implement"]):
            analysis["message_type"] = "setup"
        
        # Detect topics
        if any(term in message_lower for term in ["secret", "secrets"]):
            analysis["topics"].append("aws_secrets")
        if any(term in message_lower for term in ["deploy", "deployment", "ecs"]):
            analysis["topics"].append("deployment")
        if any(term in message_lower for term in ["docker", "container"]):
            analysis["topics"].append("containers")
        if any(term in message_lower for term in ["pipeline", "ci/cd"]):
            analysis["topics"].append("cicd")
        
        # Detect entities (service names, environments, etc.)
        entities = self._extract_entities(message)
        analysis["entities"] = entities
        
        # Detect intent
        if analysis["message_type"] == "action":
            analysis["intent"] = "execute"
        elif analysis["message_type"] == "search":
            analysis["intent"] = "retrieve"
        elif analysis["message_type"] == "setup":
            analysis["intent"] = "configure"
        else:
            analysis["intent"] = "inform"
        
        # Detect complexity
        if len(message.split()) > 15 or any(word in message_lower for word in ["setup", "configure", "implement", "pipeline"]):
            analysis["complexity"] = "complex"
        
        # Check for references to previous conversation
        if any(word in message_lower for word in ["that", "it", "them", "previous", "earlier", "before", "again"]):
            analysis["references_previous"] = True
        
        return analysis
    
    def _extract_entities(self, message: str) -> List[Dict[str, str]]:
        """Extract entities like service names, environments, etc."""
        entities = []
        message_lower = message.lower()
        
        # Environment detection
        environments = ["dev", "qa", "prod", "staging", "production"]
        for env in environments:
            if env in message_lower:
                entities.append({"type": "environment", "value": env})
        
        # Service name patterns (looking for service-name patterns)
        import re
        service_pattern = r'([a-zA-Z0-9-]+(?:-[a-zA-Z0-9]+)*)'
        matches = re.findall(service_pattern, message)
        
        for match in matches:
            if len(match) > 3 and '-' in match:  # Likely a service name
                entities.append({"type": "service", "value": match})
        
        # Key names for secrets
        key_patterns = [
            r'key\s+["\']?([a-zA-Z0-9_-]+)["\']?',
            r'containing\s+["\']?([a-zA-Z0-9_-]+)["\']?',
            r'with\s+["\']?([a-zA-Z0-9_-]+)["\']?'
        ]
        
        for pattern in key_patterns:
            matches = re.findall(pattern, message, re.IGNORECASE)
            for match in matches:
                entities.append({"type": "secret_key", "value": match})
        
        return entities
    
    def _generate_context_suggestions(self, recent_context: Dict[str, Any], current_analysis: Dict[str, Any]) -> List[str]:
        """Generate context-aware suggestions"""
        suggestions = []
        
        # If user has previous context
        if recent_context.get("has_context"):
            recent_topics = recent_context.get("last_topics", [])
            current_topics = current_analysis.get("topics", [])
            
            # Suggest related actions based on topic continuity
            if "aws_secrets" in recent_topics and "aws_secrets" in current_topics:
                suggestions.append("Review secret rotation policies based on previous findings")
            
            if "deployment" in recent_topics and current_analysis.get("message_type") == "action":
                suggestions.append("Check deployment status from previous operations")
            
            # Suggest based on recent agents used
            recent_agents = recent_context.get("recent_agents_used", [])
            if "aws_secrets_search" in recent_agents or "langchain_supervisor" in recent_agents:
                suggestions.append("Audit permissions for recently accessed secrets")
        
        # Suggest based on current message analysis
        if current_analysis.get("references_previous"):
            suggestions.append("Provide context from previous conversation")
        
        if current_analysis.get("complexity") == "complex":
            suggestions.append("Break down into step-by-step plan")
        
        return suggestions
    
    async def store_interaction(self, user_id: str, user_input: str, agent_response: Dict[str, Any], session_id: str = "default") -> bool:
        """Store the complete interaction in memory"""
        
        interaction = {
            "user_input": user_input,
            "response": agent_response,
            "session_id": session_id,
            "agent": agent_response.get("agent", "unknown"),
            "approach": agent_response.get("approach", "unknown"),
            "success": agent_response.get("success", False)
        }
        
        return await self.memory.store_message(user_id, interaction, session_id)
    
    def enhance_prompt_with_context(self, base_prompt: str, context: Dict[str, Any]) -> str:
        """Enhance the prompt with conversation context"""
        
        if not context.get("memory_available"):
            return base_prompt
        
        # Build context string
        context_parts = []
        
        # Add recent topics
        recent_topics = context.get("recent_topics", [])
        if recent_topics:
            context_parts.append(f"Recent conversation topics: {', '.join(recent_topics)}")
        
        # Add user preferences
        preferences = context.get("user_preferences", {})
        if preferences.get("preferred_approach"):
            context_parts.append(f"User prefers {preferences['preferred_approach']} approach")
        
        # Add context suggestions
        context_suggestions = context.get("context_suggestions", [])
        if context_suggestions:
            context_parts.append(f"Context suggestions: {'; '.join(context_suggestions)}")
        
        # Add recent conversation if relevant
        if context.get("current_analysis", {}).get("references_previous"):
            recent_messages = context.get("conversation_history", [])[-2:]  # Last 2 messages
            if recent_messages:
                context_parts.append("Recent conversation context:")
                for msg in recent_messages:
                    user_input = msg.get("user_input", "")[:100]
                    context_parts.append(f"- User: {user_input}")
        
        if context_parts:
            enhanced_prompt = f"""
CONVERSATION CONTEXT:
{chr(10).join(context_parts)}

CURRENT REQUEST:
{base_prompt}

Please consider the conversation context when responding and reference previous interactions when relevant.
"""
            return enhanced_prompt
        
        return base_prompt