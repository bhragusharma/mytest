"""
AWS Secrets Lambda Function
Uses the AWSSecretsWorker for Lambda deployment
"""

import json
import asyncio
import sys
import os

# Add paths for imports in Lambda environment
sys.path.append(os.path.dirname(__file__))
sys.path.append('/opt/python')  # Lambda layer path

# Import the worker (will be packaged with Lambda)
from workers.aws_secrets_worker import AWSSecretsWorker, lambda_handler as worker_handler

def lambda_handler(event, context):
    """Lambda handler that delegates to the worker"""
    return worker_handler(event, context)