"""
LangChain Supervisor Agent
Production-ready supervisor using LangChain with ReAct and Plan-Execute patterns
"""

from langchain.agents import AgentExecutor, create_react_agent
from langchain.prompts import PromptTemplate
from langchain.tools import BaseTool
from langchain_core.language_models.llms import LLM
from langchain.pydantic_v1 import BaseModel, Field
from typing import Dict, Any, List, Optional, Type
import logging
import json
import asyncio
from datetime import datetime

from memory.redis_memory import RedisMemoryManager
from memory.conversation_context import ConversationContext
from utils.ai_gateway_client import AIGatewayClient

logger = logging.getLogger(__name__)

class CustomAIGatewayLLM(LLM):
    """Custom LLM that integrates with your organization's AI Gateway"""
    
    class Config:
        arbitrary_types_allowed = True
    
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
    
    def _get_ai_gateway(self) -> AIGatewayClient:
        """Get AI Gateway client instance"""
        # Create a new instance each time to avoid Pydantic issues
        return AIGatewayClient()
    
    def _call(self, prompt: str, stop: Optional[List[str]] = None) -> str:
        """Synchronous call to AI Gateway"""
        try:
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            try:
                ai_gateway = self._get_ai_gateway()
                result = loop.run_until_complete(ai_gateway.generate_response(prompt))
                return result.get("response", "I couldn't generate a response.")
            finally:
                loop.close()
        except Exception as e:
            logger.error(f"AI Gateway LLM call error: {e}")
            return f"Error communicating with AI Gateway: {str(e)}"
    
    async def _acall(self, prompt: str, stop: Optional[List[str]] = None) -> str:
        """Asynchronous call to AI Gateway"""
        try:
            ai_gateway = self._get_ai_gateway()
            result = await ai_gateway.generate_response(prompt)
            return result.get("response", "I couldn't generate a response.")
        except Exception as e:
            logger.error(f"Async AI Gateway call error: {e}")
            return f"Error communicating with AI Gateway: {str(e)}"
    
    @property
    def _llm_type(self) -> str:
        try:
            ai_gateway = self._get_ai_gateway()
            return f"custom_ai_gateway_{ai_gateway.model}"
        except:
            return "custom_ai_gateway_gpt4o"

# Tool Input Models
class AWSSecretsInput(BaseModel):
    search_key: str = Field(description="The key name to search for in AWS secrets")

class ECSDeploymentInput(BaseModel):
    service_name: str = Field(description="Service name to deploy (e.g., commercehub-redis-buddy)")
    environment: str = Field(description="Environment tier (dev, qa, prod)")
    color: Optional[str] = Field(description="Deployment color (blue, green) - optional")

# LangChain Tools
class AWSSecretsTool(BaseTool):
    """Tool for AWS Secrets Manager operations"""
    
    name = "aws_secrets_search"
    description = """
    Search AWS Secrets Manager for secrets containing a specific key.
    Use when users ask to find, search, or list secrets with specific keys.
    Input: key name to search for (e.g., 'database_url', 'api_key', 'password')
    Returns: List of secrets containing the key with metadata.
    """
    args_schema: Type[BaseModel] = AWSSecretsInput
    
    def _run(self, search_key: str) -> str:
        """Execute AWS secrets search"""
        try:
            # Use worker agent via coordinator
            from workers.aws_secrets_worker import AWSSecretsWorker
            worker = AWSSecretsWorker()
            
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            try:
                result = loop.run_until_complete(worker.execute("search_secrets", search_key=search_key))
                return result.get("response", "No results found")
            finally:
                loop.close()
                
        except Exception as e:
            return f"Error searching AWS secrets: {str(e)}"
    
    async def _arun(self, search_key: str) -> str:
        """Async execution"""
        return self._run(search_key)

class ECSDeploymentTool(BaseTool):
    """Tool for ECS service deployments"""
    
    name = "ecs_force_deployment"
    description = """
    Force deployment of ECS services in specified clusters.
    Use when users ask to restart, deploy, or force update ECS services.
    Services are named as: <service-name>-<tier>-<color>-<random-chars>
    Clusters: ch-dev, ch-qa (where dev/qa are tiers)
    Input: service_name (e.g., commercehub-redis-buddy), environment (dev/qa), optional color
    """
    args_schema: Type[BaseModel] = ECSDeploymentInput
    
    def _run(self, service_name: str, environment: str, color: Optional[str] = None) -> str:
        """Execute ECS deployment"""
        try:
            # Use worker agent via coordinator
            from workers.ecs_deployment_worker import ECSDeploymentWorker
            worker = ECSDeploymentWorker()
            
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            try:
                result = loop.run_until_complete(worker.execute("force_deployment", 
                                                              service_name=service_name, 
                                                              environment=environment, 
                                                              color=color))
                return result.get("response", "Deployment initiated")
            finally:
                loop.close()
            
        except Exception as e:
            return f"Error initiating ECS deployment: {str(e)}"
    
    async def _arun(self, service_name: str, environment: str, color: Optional[str] = None) -> str:
        """Async execution"""
        return self._run(service_name, environment, color)

class LangChainSupervisor:
    """Production LangChain Supervisor with memory and advanced patterns"""
    
    def __init__(self):
        self.name = "langchain_supervisor"
        
        # Initialize memory system
        self.memory_manager = RedisMemoryManager()
        self.context_manager = ConversationContext(self.memory_manager)
        
        # Initialize LLM
        self.llm = CustomAIGatewayLLM()
        
        # Initialize tools
        self.tools = [
            AWSSecretsTool(),
            ECSDeploymentTool()
        ]
        
        # Create agents
        self.react_agent = self._create_react_agent()
        self.planner_agent = self._create_planner_agent()
        
        logger.info(f"LangChain Supervisor initialized with {len(self.tools)} tools and memory")
    
    def _create_react_agent(self) -> AgentExecutor:
        """Create ReAct agent with memory-enhanced prompts"""
        
        react_prompt = PromptTemplate.from_template("""
You are an advanced DevOps assistant with access to specialized tools and conversation memory.

AVAILABLE TOOLS:
{tools}

TOOL NAMES: {tool_names}

Use the ReAct pattern (Reasoning, Acting, Observing) to help users:

Question: {input}
Thought: I need to analyze this request and determine the best approach.
Action: [Choose from {tool_names} or provide direct response]
Action Input: [Input for the chosen tool]
Observation: [Result of the action]
Thought: [Analysis of the result and next steps]
Final Answer: [Comprehensive response with proactive suggestions]

IMPORTANT GUIDELINES:
1. Always consider conversation history and context
2. Use tools when you need to perform specific operations
3. Provide proactive suggestions for related actions
4. If you find AWS secrets, suggest security best practices
5. For ECS deployments, confirm environment and provide status updates
6. Reference previous conversations when relevant

{agent_scratchpad}
""")
        
        agent = create_react_agent(self.llm, self.tools, react_prompt)
        return AgentExecutor(
            agent=agent, 
            tools=self.tools, 
            verbose=True, 
            max_iterations=5,
            handle_parsing_errors=True
        )
    
    def _create_planner_agent(self) -> AgentExecutor:
        """Create Plan-and-Execute agent for complex workflows"""
        
        planner_prompt = PromptTemplate.from_template("""
You are a DevOps workflow planner with access to specialized tools and conversation memory.

AVAILABLE TOOLS:
{tools}

TOOL NAMES: {tool_names}

Create detailed execution plans for complex DevOps tasks:

User Request: {input}

Plan Structure:
1. Analyze requirements and dependencies
2. Break down into sequential steps
3. Identify tools needed for each step (choose from {tool_names})
4. Consider risks and mitigations
5. Provide implementation guidance
6. Suggest follow-up actions

Execute the plan step by step using available tools when needed.

{agent_scratchpad}
""")
        
        agent = create_react_agent(self.llm, self.tools, planner_prompt)
        return AgentExecutor(
            agent=agent, 
            tools=self.tools, 
            verbose=True, 
            max_iterations=10,
            handle_parsing_errors=True
        )
    
    async def process_message(self, message: str, user_context: Dict[str, Any]) -> Dict[str, Any]:
        """Process message with full LangChain capabilities and memory"""
        try:
            user_id = user_context.get("user_info", {}).get("username", "unknown")
            session_id = user_context.get("session_id", "default")
            
            logger.info(f"LangChain Supervisor processing message for user {user_id}")
            
            # Build conversation context
            context = await self.context_manager.build_context(user_id, message, session_id)
            
            # Enhance prompt with conversation context
            enhanced_message = self.context_manager.enhance_prompt_with_context(message, context)
            
            # Determine processing approach
            needs_planning = self._needs_complex_planning(message, context)
            
            # Execute with appropriate agent
            if needs_planning:
                logger.info("Using Plan-and-Execute approach")
                result = await self._execute_with_planning(enhanced_message)
                approach = "planning"
            else:
                logger.info("Using ReAct approach")
                result = await self._execute_with_react(enhanced_message)
                approach = "react"
            
            # Generate enhanced suggestions
            suggestions = self._generate_enhanced_suggestions(message, result, context)
            
            # Prepare response
            response = {
                "success": True,
                "response": result,
                "agent": self.name,
                "approach": approach,
                "suggestions": suggestions,
                "tools_used": self._extract_tools_used(result),
                "memory_used": context.get("memory_available", False),
                "context_topics": context.get("recent_topics", [])
            }
            
            # Store interaction in memory
            await self.context_manager.store_interaction(user_id, message, response, session_id)
            
            return response
            
        except Exception as e:
            logger.error(f"LangChain Supervisor error: {e}")
            return {
                "success": False,
                "response": f"I encountered an error processing your request: {str(e)}",
                "agent": self.name,
                "error": str(e)
            }
    
    def _needs_complex_planning(self, message: str, context: Dict[str, Any]) -> bool:
        """Determine if complex planning is needed"""
        message_lower = message.lower()
        
        # Complex keywords
        planning_keywords = [
            "setup", "configure", "implement", "deploy", "pipeline", 
            "migrate", "optimize", "troubleshoot", "audit", "compliance"
        ]
        
        # Check message complexity
        keyword_count = sum(1 for keyword in planning_keywords if keyword in message_lower)
        has_sequence = any(word in message_lower for word in ["then", "after", "next", "step"])
        is_long = len(message.split()) > 15
        
        # Check context for complexity indicators
        current_analysis = context.get("current_analysis", {})
        is_complex_type = current_analysis.get("complexity") == "complex"
        
        return keyword_count >= 2 or has_sequence or is_long or is_complex_type
    
    async def _execute_with_react(self, message: str) -> str:
        """Execute using ReAct pattern"""
        try:
            loop = asyncio.get_event_loop()
            result = await loop.run_in_executor(
                None,
                lambda: self.react_agent.invoke({"input": message})
            )
            return result.get("output", "No response generated")
        except Exception as e:
            logger.error(f"ReAct execution error: {e}")
            return f"Error in ReAct execution: {str(e)}"
    
    async def _execute_with_planning(self, message: str) -> str:
        """Execute using Plan-and-Execute pattern"""
        try:
            planning_message = f"""
Create and execute a comprehensive DevOps plan for: {message}

Consider:
1. Prerequisites and dependencies
2. Step-by-step execution with tools
3. Risk assessment and mitigations
4. Validation and testing
5. Follow-up monitoring
"""
            
            loop = asyncio.get_event_loop()
            result = await loop.run_in_executor(
                None,
                lambda: self.planner_agent.invoke({"input": planning_message})
            )
            return result.get("output", "No plan generated")
        except Exception as e:
            logger.error(f"Planning execution error: {e}")
            return f"Error in planning execution: {str(e)}"
    
    def _generate_enhanced_suggestions(self, message: str, response: str, context: Dict[str, Any]) -> List[str]:
        """Generate context-aware suggestions"""
        suggestions = []
        message_lower = message.lower()
        
        # Context-based suggestions
        context_suggestions = context.get("context_suggestions", [])
        suggestions.extend(context_suggestions)
        
        # Topic-based suggestions
        if "secret" in message_lower:
            suggestions.extend([
                "🔐 Set up automated secret rotation",
                "🛡️ Review secret access audit logs",
                "📊 Monitor secret usage patterns"
            ])
        
        if any(term in message_lower for term in ["deploy", "ecs", "restart"]):
            suggestions.extend([
                "📈 Monitor deployment metrics",
                "🔄 Set up automated rollback triggers",
                "🧪 Validate service health checks"
            ])
        
        # Memory-based suggestions
        recent_topics = context.get("recent_topics", [])
        if "aws_secrets" in recent_topics and "deployment" in message_lower:
            suggestions.append("🔗 Verify deployment uses updated secrets")
        
        return list(set(suggestions))[:5]  # Remove duplicates, limit to 5
    
    def _extract_tools_used(self, response: str) -> List[str]:
        """Extract tools used from response"""
        tools_used = []
        response_lower = response.lower()
        
        for tool in self.tools:
            if tool.name in response_lower or any(keyword in response_lower for keyword in tool.description.split()):
                tools_used.append(tool.name)
        
        return tools_used
    
    def get_capabilities(self) -> Dict[str, Any]:
        """Get supervisor capabilities"""
        return {
            "name": self.name,
            "patterns": ["ReAct", "Plan-and-Execute"],
            "features": [
                "Conversation Memory (Redis)",
                "Context-Aware Responses", 
                "LangChain Integration",
                "AI Gateway (GPT-4o)",
                "Lambda Worker Coordination",
                "Advanced Error Recovery"
            ],
            "tools": [{"name": tool.name, "description": tool.description} for tool in self.tools],
            "memory_available": self.memory_manager.is_available()
        }