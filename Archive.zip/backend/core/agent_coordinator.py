"""
Agent Coordinator
Manages communication between Fargate supervisor and Lambda worker agents
"""

import boto3
import json
import os
from typing import Dict, Any, Optional
import logging

logger = logging.getLogger(__name__)

class AgentCoordinator:
    """Coordinates between supervisor (Fargate) and worker agents (Lambda)"""
    
    def __init__(self):
        # Initialize AWS Lambda client
        self.lambda_client = boto3.client('lambda')
        
        # Lambda function names (will be loaded from environment/secrets)
        self.lambda_functions = {
            "aws_secrets_worker": os.getenv("AWS_SECRETS_LAMBDA_FUNCTION", "aws-secrets-worker"),
            "ecs_deployment_worker": os.getenv("ECS_DEPLOYMENT_LAMBDA_FUNCTION", "ecs-deployment-worker")
        }
        
        logger.info(f"Agent Coordinator initialized with {len(self.lambda_functions)} Lambda functions")
    
    async def call_worker_agent(self, worker_name: str, action: str, **kwargs) -> Dict[str, Any]:
        """Call a Lambda worker agent using AWS SDK"""
        try:
            function_name = self.lambda_functions.get(worker_name)
            
            if not function_name:
                logger.error(f"No Lambda function configured for worker: {worker_name}")
                return {
                    "success": False,
                    "response": f"Worker agent '{worker_name}' is not configured",
                    "error": "worker_not_configured"
                }
            
            # Prepare payload for Lambda
            payload = {
                "action": action,
                **kwargs
            }
            
            # Invoke Lambda function
            try:
                response = self.lambda_client.invoke(
                    FunctionName=function_name,
                    InvocationType='RequestResponse',  # Synchronous invocation
                    Payload=json.dumps(payload)
                )
                
                # Parse response
                response_payload = json.loads(response['Payload'].read())
                
                # Check if Lambda execution was successful
                if response['StatusCode'] == 200:
                    # Lambda executed successfully, check the actual response
                    if response_payload.get('statusCode') == 200:
                        # Parse the body from Lambda response
                        body = response_payload.get('body')
                        if isinstance(body, str):
                            result = json.loads(body)
                        else:
                            result = body
                        
                        logger.info(f"Successfully called {worker_name} Lambda function")
                        return result
                    else:
                        logger.error(f"Lambda {worker_name} returned error: {response_payload}")
                        return {
                            "success": False,
                            "response": f"Lambda function error: {response_payload.get('body', 'Unknown error')}",
                            "error": "lambda_function_error"
                        }
                else:
                    logger.error(f"Lambda invocation failed with status {response['StatusCode']}")
                    return {
                        "success": False,
                        "response": f"Lambda invocation failed (status {response['StatusCode']})",
                        "error": "lambda_invocation_error"
                    }
                    
            except self.lambda_client.exceptions.ResourceNotFoundException:
                logger.error(f"Lambda function {function_name} not found")
                return {
                    "success": False,
                    "response": f"Lambda function '{function_name}' not found",
                    "error": "function_not_found"
                }
            except Exception as e:
                logger.error(f"Error invoking Lambda {function_name}: {e}")
                return {
                    "success": False,
                    "response": f"Error invoking Lambda function: {str(e)}",
                    "error": "invocation_error"
                }
                    
        except Exception as e:
            logger.error(f"Error calling worker {worker_name}: {e}")
            return {
                "success": False,
                "response": f"Error communicating with worker '{worker_name}': {str(e)}",
                "error": "communication_error"
            }
    
    async def call_aws_secrets_worker(self, action: str = "search_secrets", **kwargs) -> Dict[str, Any]:
        """Convenience method for AWS Secrets worker"""
        return await self.call_worker_agent("aws_secrets_worker", action, **kwargs)
    
    async def call_ecs_deployment_worker(self, action: str = "force_deployment", **kwargs) -> Dict[str, Any]:
        """Convenience method for ECS Deployment worker"""
        return await self.call_worker_agent("ecs_deployment_worker", action, **kwargs)
    
    def get_worker_status(self) -> Dict[str, Any]:
        """Get status of all configured workers"""
        status = {
            "total_workers": len(self.lambda_functions),
            "configured_workers": [],
            "missing_workers": []
        }
        
        for worker_name, function_name in self.lambda_functions.items():
            if function_name:
                status["configured_workers"].append({
                    "name": worker_name,
                    "function_name": function_name,
                    "status": "configured"
                })
            else:
                status["missing_workers"].append({
                    "name": worker_name,
                    "status": "not_configured"
                })
        
        return status
    
    async def health_check_workers(self) -> Dict[str, Any]:
        """Perform health check on all worker agents"""
        health_results = {}
        
        for worker_name, function_name in self.lambda_functions.items():
            if not function_name:
                health_results[worker_name] = {
                    "status": "not_configured",
                    "error": "No function name configured"
                }
                continue
            
            try:
                # Try to get function configuration (lightweight health check)
                response = self.lambda_client.get_function_configuration(
                    FunctionName=function_name
                )
                
                health_results[worker_name] = {
                    "status": "healthy",
                    "function_name": function_name,
                    "state": response.get('State', 'Unknown'),
                    "last_modified": response.get('LastModified', 'Unknown')
                }
                        
            except self.lambda_client.exceptions.ResourceNotFoundException:
                health_results[worker_name] = {
                    "status": "not_found",
                    "error": f"Lambda function '{function_name}' not found"
                }
            except Exception as e:
                health_results[worker_name] = {
                    "status": "error",
                    "error": str(e)
                }
        
        return {
            "timestamp": "now",
            "workers": health_results,
            "healthy_count": sum(1 for r in health_results.values() if r.get("status") == "healthy"),
            "total_count": len(health_results)
        }