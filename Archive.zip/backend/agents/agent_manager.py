"""
Agent Manager
Production-ready agent manager with LangChain supervisor and Lambda workers
"""

from typing import Dict, Any
import logging
from core.langchain_supervisor import LangChainSupervisor
from core.agent_coordinator import AgentCoordinator

logger = logging.getLogger(__name__)

class AgentManager:
    """Production agent manager with LangChain and Lambda integration"""
    
    def __init__(self):
        try:
            # Initialize LangChain supervisor
            self.supervisor = LangChainSupervisor()
            
            # Initialize agent coordinator for Lambda workers
            self.coordinator = AgentCoordinator()
            
            logger.info("Agent Manager initialized with LangChain Supervisor and Lambda coordination")
            
        except Exception as e:
            logger.error(f"Failed to initialize Agent Manager: {e}")
            raise
    
    async def process_message(self, message: str, context: Dict[str, Any] = None) -> Dict[str, Any]:
        """
        Process a user message through the LangChain agent system
        
        Args:
            message: User's message/query
            context: Additional context (user info, session data, etc.)
            
        Returns:
            Dict containing the agent response with enhanced features
        """
        try:
            logger.info(f"Processing message through LangChain supervisor: {message[:100]}...")
            
            # Add default context if none provided
            if context is None:
                context = {}
            
            # Add coordinator to context for Lambda calls
            context["coordinator"] = self.coordinator
            
            # Process through LangChain supervisor
            result = await self.supervisor.process_message(message, context)
            
            # Add metadata
            result["timestamp"] = context.get("timestamp")
            result["processed_by"] = "agent_manager_langchain"
            result["langchain_enabled"] = True
            
            return result
            
        except Exception as e:
            logger.error(f"Error in agent manager: {str(e)}")
            return {
                "success": False,
                "response": f"I encountered an error while processing your message: {str(e)}",
                "agent": "agent_manager",
                "error": str(e)
            }
    
    async def get_system_status(self) -> Dict[str, Any]:
        """Get comprehensive system status"""
        try:
            # Get supervisor capabilities
            supervisor_capabilities = self.supervisor.get_capabilities()
            
            # Get worker status
            worker_status = self.coordinator.get_worker_status()
            
            # Get memory status
            memory_available = supervisor_capabilities.get("memory_available", False)
            
            return {
                "supervisor_type": "langchain",
                "supervisor": supervisor_capabilities,
                "workers": worker_status,
                "memory_system": {
                    "available": memory_available,
                    "type": "redis_with_ttl"
                },
                "status": "active",
                "features": [
                    "LangChain Integration",
                    "ReAct Pattern", 
                    "Plan-and-Execute",
                    "Conversation Memory",
                    "Lambda Workers",
                    "Proactive Suggestions"
                ]
            }
            
        except Exception as e:
            logger.error(f"Error getting system status: {str(e)}")
            return {
                "error": str(e),
                "status": "error"
            }
    
    def get_available_agents(self) -> Dict[str, Any]:
        """Get information about available agents and workers"""
        try:
            supervisor_capabilities = self.supervisor.get_capabilities()
            worker_status = self.coordinator.get_worker_status()
            
            return {
                "supervisor_type": "langchain",
                "supervisor": supervisor_capabilities,
                "lambda_workers": worker_status["configured_workers"],
                "features": [
                    "Advanced Reasoning (ReAct)",
                    "Complex Planning (Plan-Execute)", 
                    "Conversation Memory",
                    "Proactive Suggestions",
                    "Lambda Worker Coordination"
                ]
            }
            
        except Exception as e:
            logger.error(f"Error getting agent info: {str(e)}")
            return {
                "error": str(e)
            }
    
    async def health_check(self) -> Dict[str, Any]:
        """Perform comprehensive health check"""
        try:
            # Check supervisor
            supervisor_status = "healthy"
            
            # Check workers
            worker_health = await self.coordinator.health_check_workers()
            
            # Check memory system
            memory_status = "unknown"
            if hasattr(self.supervisor, 'memory_manager'):
                memory_status = "healthy" if self.supervisor.memory_manager.is_available() else "unavailable"
            
            return {
                "overall_status": "healthy",
                "supervisor": supervisor_status,
                "workers": worker_health,
                "memory_system": memory_status,
                "timestamp": "now"
            }
            
        except Exception as e:
            logger.error(f"Health check error: {e}")
            return {
                "overall_status": "error",
                "error": str(e)
            }
    
    async def get_memory_stats(self, user_id: str) -> Dict[str, Any]:
        """Get memory statistics for a user"""
        try:
            if hasattr(self.supervisor, 'memory_manager'):
                return await self.supervisor.memory_manager.get_memory_stats(user_id)
            else:
                return {"available": False, "message": "Memory system not available"}
        except Exception as e:
            logger.error(f"Error getting memory stats: {e}")
            return {"available": False, "error": str(e)}
    
    async def clear_user_memory(self, user_id: str) -> Dict[str, Any]:
        """Clear memory for a specific user"""
        try:
            if hasattr(self.supervisor, 'memory_manager'):
                success = await self.supervisor.memory_manager.clear_user_memory(user_id)
                return {
                    "success": success,
                    "message": f"Memory cleared for user {user_id}" if success else "Failed to clear memory"
                }
            else:
                return {"success": False, "message": "Memory system not available"}
        except Exception as e:
            logger.error(f"Error clearing user memory: {e}")
            return {"success": False, "error": str(e)}