"""
AI Gateway Client
Enhanced client for organization's AI Gateway with GPT-4o model
"""

import httpx
import os
import json
from typing import Dict, Any, Optional, List
import logging

logger = logging.getLogger(__name__)

class AIGatewayClient:
    """Enhanced client for AI Gateway with GPT-4o integration"""
    
    def __init__(self):
        self.gateway_url = os.getenv("AI_GATEWAY_URL")
        self.api_key = os.getenv("API_KEY")
        self.api_secret = os.getenv("API_SECRET")
        self.model = os.getenv("AI_MODEL", "gpt-4o")
        self.max_tokens = int(os.getenv("AI_MAX_TOKENS", "2000"))
        self.temperature = float(os.getenv("AI_TEMPERATURE", "0.7"))
        
        if not all([self.gateway_url, self.api_key, self.api_secret]):
            logger.warning("AI Gateway credentials not fully configured")
    
    async def generate_response(self, prompt: str, context: Dict[str, Any] = None) -> Dict[str, Any]:
        """
        Generate a response using the organization's AI Gateway with GPT-4o
        
        Args:
            prompt: The user prompt/question
            context: Additional context for the LLM
            
        Returns:
            Dict containing the LLM response
        """
        try:
            if not self._is_configured():
                return {
                    "success": False,
                    "response": "AI Gateway is not properly configured. Please check your credentials.",
                    "error": "missing_credentials"
                }
            
            # Prepare the request payload for your organization's gateway
            payload = {
                "api_key": self.api_key,
                "api_secret": self.api_secret,
                "prompt": prompt,
                "model": self.model,
                "max_tokens": self.max_tokens,
                "temperature": self.temperature,
                "context": context or {}
            }
            
            # Add system message for DevOps context
            if context:
                system_message = """You are an expert DevOps assistant with deep knowledge of:
- AWS services and cloud architecture
- CI/CD pipelines and automation
- Infrastructure as Code (Terraform, CloudFormation)
- Container technologies (Docker, Kubernetes)
- Monitoring and observability
- Security best practices
- Deployment strategies and rollback procedures

Provide practical, actionable advice with specific examples when possible."""
                
                payload["system_message"] = system_message
            
            async with httpx.AsyncClient(timeout=60.0) as client:
                response = await client.post(
                    self.gateway_url,
                    json=payload,
                    headers={
                        "Content-Type": "application/json",
                        "User-Agent": "DevOps-Chatbot-LangChain/2.0",
                        "X-Request-Source": "supervisor-agent"
                    }
                )
                
                if response.status_code == 200:
                    result = response.json()
                    
                    # Extract response based on your gateway's format
                    ai_response = result.get("response", result.get("message", result.get("content", "No response received")))
                    
                    return {
                        "success": True,
                        "response": ai_response,
                        "model": result.get("model", self.model),
                        "tokens_used": result.get("tokens_used", result.get("usage", {}).get("total_tokens", 0)),
                        "finish_reason": result.get("finish_reason", "completed")
                    }
                else:
                    logger.error(f"AI Gateway returned status {response.status_code}: {response.text}")
                    return {
                        "success": False,
                        "response": f"AI Gateway error (status {response.status_code})",
                        "error": "gateway_error",
                        "status_code": response.status_code
                    }
                    
        except httpx.TimeoutException:
            logger.error("AI Gateway request timed out")
            return {
                "success": False,
                "response": "AI Gateway request timed out. Please try again.",
                "error": "timeout"
            }
        except Exception as e:
            logger.error(f"AI Gateway client error: {str(e)}")
            return {
                "success": False,
                "response": f"Error communicating with AI Gateway: {str(e)}",
                "error": "client_error"
            }
    
    async def generate_with_tools_context(self, prompt: str, available_tools: List[str], context: Dict[str, Any] = None) -> Dict[str, Any]:
        """Generate response with tools context for LangChain integration"""
        
        tools_description = f"""
Available DevOps Tools:
{chr(10).join(f"- {tool}" for tool in available_tools)}

Use these tools when you need to perform specific operations.
"""
        
        enhanced_prompt = f"{tools_description}\n\nUser Request: {prompt}"
        
        return await self.generate_response(enhanced_prompt, context)
    
    def _is_configured(self) -> bool:
        """Check if the AI Gateway is properly configured"""
        return bool(self.gateway_url and self.api_key and self.api_secret)
    
    async def test_connection(self) -> Dict[str, Any]:
        """Test the connection to AI Gateway"""
        try:
            test_response = await self.generate_response(
                "Hello, this is a connection test. Please respond with 'Connection successful' and confirm you're using GPT-4o."
            )
            return test_response
        except Exception as e:
            return {
                "success": False,
                "response": f"Connection test failed: {str(e)}",
                "error": "connection_test_failed"
            }
    
    def get_model_info(self) -> Dict[str, Any]:
        """Get information about the configured model"""
        return {
            "model": self.model,
            "max_tokens": self.max_tokens,
            "temperature": self.temperature,
            "gateway_url": self.gateway_url[:50] + "..." if self.gateway_url and len(self.gateway_url) > 50 else self.gateway_url,
            "configured": self._is_configured()
        }