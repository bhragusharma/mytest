"""
AWS Secrets Manager Loader
Enhanced loader that reads secrets from AWS and sets them as environment variables
Supports Redis configuration and other advanced settings
"""

import boto3
import json
import os
import logging

logger = logging.getLogger(__name__)

def load_secrets_to_environment(region: str = None, secret_name: str = None):
    """
    Load secrets from AWS and set as environment variables
    
    Expected secrets in /test/secret:
    - GATEWAY_URL: AI Gateway endpoint URL
    - API_KEY: AI Gateway API key  
    - API_SECRET: AI Gateway API secret
    - AGENT_USERNAME: Username for agent authentication
    - AGENT_PASSWORD: Password for agent authentication
    - JWT_SECRET: Secret for JWT token signing
    - AI_GATEWAY_URL: Full AI Gateway URL
    - AI_MODEL: AI model to use (default: gpt-4o)
    - AI_MAX_TOKENS: Maximum tokens for AI responses
    - AI_TEMPERATURE: AI response temperature
    - REDIS_HOST: Redis cluster host
    - REDIS_PORT: Redis cluster port
    - REDIS_PASSWORD: Redis cluster password
    - REDIS_SSL: Whether to use SSL for Redis (true/false)
    - AWS_SECRETS_LAMBDA_FUNCTION: Lambda function name for AWS Secrets agent
    - ECS_DEPLOY_LAMBDA_FUNCTION: Lambda function name for ECS Deploy agent
    
    Args:
        region: AWS region (defaults to AWS_REGION env var or us-east-1)
        secret_name: Secret name (defaults to AWS_SECRET_NAME env var or /test/secret)
    """
    try:
        # Use environment variables or defaults
        region = region or os.getenv("AWS_REGION", "us-east-1")
        secret_name = secret_name or os.getenv("AWS_SECRET_NAME", "/test/secret")
        
        logger.info(f"Loading secrets from {secret_name} in region {region}")
        
        # Create AWS Secrets Manager client
        client = boto3.client('secretsmanager', region_name=region)
        
        # Get the secret value
        response = client.get_secret_value(SecretId=secret_name)
        secret_data = json.loads(response['SecretString'])
        
        # Set all keys from secret as environment variables
        for key, value in secret_data.items():
            os.environ[key] = str(value)
            logger.debug(f"Set environment variable: {key}")
        
        # Validate required configurations
        _validate_configurations()
        
        logger.info(f"Successfully loaded {len(secret_data)} configuration values from AWS Secrets Manager")
        
    except Exception as e:
        logger.error(f"Failed to load secrets from AWS: {e}")
        raise

def _validate_configurations():
    """Validate that required configurations are present"""
    
    required_configs = [
        "GATEWAY_URL", "API_KEY", "API_SECRET", 
        "AGENT_USERNAME", "AGENT_PASSWORD", "JWT_SECRET"
    ]
    
    missing_configs = []
    for config in required_configs:
        if not os.getenv(config):
            missing_configs.append(config)
    
    if missing_configs:
        logger.warning(f"Missing required configurations: {', '.join(missing_configs)}")
    
    # Validate Redis configuration
    redis_host = os.getenv("REDIS_HOST")
    if redis_host:
        logger.info("Redis configuration found")
        redis_port = os.getenv("REDIS_PORT", "6379")
        redis_ssl = os.getenv("REDIS_SSL", "false").lower() == "true"
        logger.info(f"Redis: {redis_host}:{redis_port} (SSL: {redis_ssl})")
    else:
        logger.warning("Redis configuration not found - conversation memory will be disabled")
    
    # Validate AI Gateway configuration
    ai_gateway_url = os.getenv("AI_GATEWAY_URL")
    ai_model = os.getenv("AI_MODEL", "gpt-4o")
    if ai_gateway_url:
        logger.info(f"AI Gateway configured: {ai_model} model")
    else:
        logger.warning("AI Gateway URL not configured")
    
    # Validate Lambda function configuration
    aws_secrets_lambda = os.getenv("AWS_SECRETS_LAMBDA_FUNCTION")
    ecs_deploy_lambda = os.getenv("ECS_DEPLOY_LAMBDA_FUNCTION")
    
    if aws_secrets_lambda and ecs_deploy_lambda:
        logger.info(f"Lambda functions configured:")
        logger.info(f"  AWS Secrets: {aws_secrets_lambda}")
        logger.info(f"  ECS Deploy: {ecs_deploy_lambda}")
    else:
        logger.warning("Lambda function names not configured - using defaults")

def get_redis_config() -> dict:
    """Get Redis configuration from environment variables"""
    
    return {
        "host": os.getenv("REDIS_HOST"),
        "port": int(os.getenv("REDIS_PORT", 6379)),
        "password": os.getenv("REDIS_PASSWORD"),
        "ssl": os.getenv("REDIS_SSL", "false").lower() == "true",
        "decode_responses": True,
        "socket_timeout": 5,
        "socket_connect_timeout": 5,
        "retry_on_timeout": True
    }

def get_ai_gateway_config() -> dict:
    """Get AI Gateway configuration from environment variables"""
    
    return {
        "gateway_url": os.getenv("AI_GATEWAY_URL"),
        "api_key": os.getenv("API_KEY"),
        "api_secret": os.getenv("API_SECRET"),
        "model": os.getenv("AI_MODEL", "gpt-4o"),
        "max_tokens": int(os.getenv("AI_MAX_TOKENS", 2000)),
        "temperature": float(os.getenv("AI_TEMPERATURE", 0.7))
    }


if __name__ == "__main__":
    # Test the secrets loader
    load_secrets_to_environment()
    print("Secrets loaded to environment variables")