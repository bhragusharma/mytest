"""
AWS Secrets Worker Agent
Enhanced version designed for AWS Lambda execution
"""

import boto3
import json
import re
from typing import Dict, Any, List
import logging

logger = logging.getLogger(__name__)

class AWSSecretsWorker:
    """Enhanced AWS Secrets Manager worker for Lambda execution"""
    
    def __init__(self):
        self.name = "aws_secrets_worker"
        self.secrets_client = boto3.client('secretsmanager')
    
    async def execute(self, action: str, **kwargs) -> Dict[str, Any]:
        """Execute secrets management action"""
        try:
            if action == "search_secrets":
                return await self._search_secrets(**kwargs)
            elif action == "get_secret_value":
                return await self._get_secret_value(**kwargs)
            elif action == "list_all_secrets":
                return await self._list_all_secrets(**kwargs)
            else:
                return {
                    "success": False,
                    "response": f"Unknown action: {action}",
                    "error": "invalid_action"
                }
        except Exception as e:
            logger.error(f"AWS Secrets Worker error: {e}")
            return {
                "success": False,
                "response": f"Error executing secrets operation: {str(e)}",
                "error": str(e)
            }
    
    async def _search_secrets(self, search_key: str) -> Dict[str, Any]:
        """Search for secrets containing a specific key"""
        try:
            logger.info(f"Searching for secrets containing key: {search_key}")
            
            # Get all secrets
            paginator = self.secrets_client.get_paginator('list_secrets')
            matching_secrets = []
            
            for page in paginator.paginate():
                for secret in page['SecretList']:
                    secret_name = secret['Name']
                    
                    try:
                        # Get secret value
                        response = self.secrets_client.get_secret_value(SecretId=secret_name)
                        secret_string = response['SecretString']
                        
                        # Parse and check for key
                        secret_data = self._parse_secret_data(secret_string)
                        
                        if self._key_exists_in_secret(search_key, secret_data, secret_string):
                            matching_secrets.append({
                                "name": secret_name,
                                "description": secret.get('Description', 'No description'),
                                "key_found": search_key,
                                "key_value": self._get_masked_value(secret_data, search_key),
                                "created_date": secret.get('CreatedDate', '').isoformat() if secret.get('CreatedDate') else 'Unknown',
                                "last_changed": secret.get('LastChangedDate', '').isoformat() if secret.get('LastChangedDate') else 'Unknown',
                                "tags": secret.get('Tags', [])
                            })
                    
                    except Exception as e:
                        logger.warning(f"Error accessing secret {secret_name}: {str(e)}")
                        continue
            
            if not matching_secrets:
                return {
                    "success": True,
                    "response": f"No secrets found containing the key '{search_key}' in your AWS account.",
                    "data": {
                        "search_key": search_key,
                        "matching_secrets": []
                    }
                }
            
            # Format response
            response_text = self._format_secrets_response(search_key, matching_secrets)
            
            return {
                "success": True,
                "response": response_text,
                "data": {
                    "search_key": search_key,
                    "matching_secrets": matching_secrets,
                    "count": len(matching_secrets)
                }
            }
            
        except Exception as e:
            logger.error(f"Error searching secrets: {e}")
            return {
                "success": False,
                "response": f"Error searching AWS secrets: {str(e)}",
                "error": str(e)
            }
    
    def _parse_secret_data(self, secret_string: str) -> Dict[str, Any]:
        """Parse secret string as JSON or return as plain text"""
        try:
            return json.loads(secret_string)
        except json.JSONDecodeError:
            return {"_raw_value": secret_string}
    
    def _key_exists_in_secret(self, search_key: str, secret_data: Dict[str, Any], raw_string: str) -> bool:
        """Check if key exists in secret data"""
        search_key_lower = search_key.lower()
        
        # Check in parsed JSON data
        if isinstance(secret_data, dict) and "_raw_value" not in secret_data:
            for key in secret_data.keys():
                if search_key_lower in key.lower():
                    return True
        
        # Check in raw string (case-insensitive)
        return search_key_lower in raw_string.lower()
    
    def _get_masked_value(self, secret_data: Dict[str, Any], search_key: str) -> str:
        """Get masked value for the found key"""
        if isinstance(secret_data, dict) and "_raw_value" not in secret_data:
            for key, value in secret_data.items():
                if search_key.lower() in key.lower():
                    if value:
                        # Mask the value for security
                        if len(str(value)) > 8:
                            return f"{str(value)[:3]}***{str(value)[-2:]}"
                        else:
                            return "***"
                    else:
                        return "empty"
        
        return "found in text"
    
    def _format_secrets_response(self, search_key: str, matching_secrets: List[Dict[str, Any]]) -> str:
        """Format the response for display"""
        count = len(matching_secrets)
        
        response = f"🔍 Found {count} secret{'s' if count != 1 else ''} containing the key '{search_key}':\n\n"
        
        for i, secret in enumerate(matching_secrets, 1):
            response += f"**{i}. {secret['name']}**\n"
            response += f"   📝 Description: {secret['description']}\n"
            response += f"   🔑 Key '{search_key}': {secret['key_value']}\n"
            response += f"   📅 Created: {secret['created_date']}\n"
            response += f"   🔄 Last Changed: {secret['last_changed']}\n"
            
            # Add tags if available
            if secret.get('tags'):
                tag_list = [f"{tag['Key']}={tag['Value']}" for tag in secret['tags'][:3]]
                response += f"   🏷️ Tags: {', '.join(tag_list)}\n"
            
            response += "\n"
        
        # Add security recommendations
        response += "🛡️ **Security Recommendations:**\n"
        response += "• Review access permissions for these secrets\n"
        response += "• Consider implementing secret rotation\n"
        response += "• Audit applications using these secrets\n"
        response += "• Monitor secret access logs\n"
        
        return response.strip()
    
    async def _get_secret_value(self, secret_name: str, version_id: str = None) -> Dict[str, Any]:
        """Get the value of a specific secret"""
        try:
            params = {"SecretId": secret_name}
            if version_id:
                params["VersionId"] = version_id
            
            response = self.secrets_client.get_secret_value(**params)
            
            # Parse the secret
            secret_data = self._parse_secret_data(response['SecretString'])
            
            # Format response (with masked values for security)
            if isinstance(secret_data, dict) and "_raw_value" not in secret_data:
                masked_data = {}
                for key, value in secret_data.items():
                    if value:
                        masked_data[key] = self._get_masked_value({key: value}, key)
                    else:
                        masked_data[key] = "empty"
                
                response_text = f"""
Secret: {secret_name}

Keys and Values (masked):
"""
                for key, masked_value in masked_data.items():
                    response_text += f"  • {key}: {masked_value}\n"
            else:
                response_text = f"""
Secret: {secret_name}
Type: Plain text
Content: [masked for security]
"""
            
            return {
                "success": True,
                "response": response_text.strip(),
                "data": {
                    "secret_name": secret_name,
                    "keys": list(secret_data.keys()) if isinstance(secret_data, dict) else ["_raw_value"],
                    "version_id": response.get('VersionId')
                }
            }
            
        except Exception as e:
            logger.error(f"Error getting secret value: {e}")
            return {
                "success": False,
                "response": f"Error retrieving secret '{secret_name}': {str(e)}",
                "error": str(e)
            }
    
    async def _list_all_secrets(self, max_results: int = 50) -> Dict[str, Any]:
        """List all secrets in the account"""
        try:
            paginator = self.secrets_client.get_paginator('list_secrets')
            all_secrets = []
            
            count = 0
            for page in paginator.paginate():
                for secret in page['SecretList']:
                    if count >= max_results:
                        break
                    
                    all_secrets.append({
                        "name": secret['Name'],
                        "description": secret.get('Description', 'No description'),
                        "created_date": secret.get('CreatedDate', '').isoformat() if secret.get('CreatedDate') else 'Unknown',
                        "last_changed": secret.get('LastChangedDate', '').isoformat() if secret.get('LastChangedDate') else 'Unknown'
                    })
                    count += 1
                
                if count >= max_results:
                    break
            
            # Format response
            response_text = f"📋 AWS Secrets Manager - All Secrets (showing {len(all_secrets)}):\n\n"
            
            for i, secret in enumerate(all_secrets, 1):
                response_text += f"{i}. **{secret['name']}**\n"
                response_text += f"   📝 {secret['description']}\n"
                response_text += f"   📅 Created: {secret['created_date']}\n\n"
            
            if len(all_secrets) == max_results:
                response_text += f"... (showing first {max_results} secrets)\n"
            
            return {
                "success": True,
                "response": response_text.strip(),
                "data": {
                    "secrets": all_secrets,
                    "total_shown": len(all_secrets),
                    "truncated": len(all_secrets) == max_results
                }
            }
            
        except Exception as e:
            logger.error(f"Error listing secrets: {e}")
            return {
                "success": False,
                "response": f"Error listing AWS secrets: {str(e)}",
                "error": str(e)
            }

# Lambda handler function
def lambda_handler(event, context):
    """AWS Lambda handler for AWS Secrets worker"""
    try:
        worker = AWSSecretsWorker()
        
        # Extract parameters from event
        action = event.get('action', 'search_secrets')
        kwargs = {k: v for k, v in event.items() if k != 'action'}
        
        # Execute action (note: this is sync in Lambda)
        import asyncio
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        
        try:
            result = loop.run_until_complete(worker.execute(action, **kwargs))
        finally:
            loop.close()
        
        return {
            'statusCode': 200,
            'body': json.dumps(result)
        }
        
    except Exception as e:
        logger.error(f"Lambda handler error: {e}")
        return {
            'statusCode': 500,
            'body': json.dumps({
                'success': False,
                'error': str(e)
            })
        }