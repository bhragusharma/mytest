"""
ECS Deployment Worker Agent
Handles ECS service force deployments - designed for AWS Lambda execution
"""

import boto3
import json
import re
from typing import Dict, Any, List, Optional
import logging

logger = logging.getLogger(__name__)

class ECSDeploymentWorker:
    """Worker agent for ECS service deployments"""
    
    def __init__(self):
        self.name = "ecs_deployment_worker"
        self.ecs_client = boto3.client('ecs')
        
        # Cluster mapping
        self.cluster_mapping = {
            "dev": "ch-dev",
            "qa": "ch-qa",
            "prod": "ch-prod"  # Add if needed
        }
    
    async def execute(self, action: str, **kwargs) -> Dict[str, Any]:
        """Execute ECS deployment action"""
        try:
            if action == "force_deployment":
                return await self._force_deployment(**kwargs)
            elif action == "list_services":
                return await self._list_services(**kwargs)
            elif action == "get_service_status":
                return await self._get_service_status(**kwargs)
            else:
                return {
                    "success": False,
                    "response": f"Unknown action: {action}",
                    "error": "invalid_action"
                }
        except Exception as e:
            logger.error(f"ECS Worker error: {e}")
            return {
                "success": False,
                "response": f"Error executing ECS operation: {str(e)}",
                "error": str(e)
            }
    
    async def _force_deployment(self, service_name: str, environment: str, color: Optional[str] = None) -> Dict[str, Any]:
        """Force deployment of ECS services"""
        try:
            # Validate environment
            if environment not in self.cluster_mapping:
                return {
                    "success": False,
                    "response": f"Invalid environment '{environment}'. Valid options: {', '.join(self.cluster_mapping.keys())}",
                    "error": "invalid_environment"
                }
            
            cluster_name = self.cluster_mapping[environment]
            
            # Find matching services
            matching_services = await self._find_matching_services(cluster_name, service_name, environment, color)
            
            if not matching_services:
                return {
                    "success": False,
                    "response": f"No services found matching pattern '{service_name}' in environment '{environment}'",
                    "error": "no_services_found"
                }
            
            # Force deployment for each matching service
            deployment_results = []
            
            for service in matching_services:
                try:
                    response = self.ecs_client.update_service(
                        cluster=cluster_name,
                        service=service["serviceName"],
                        forceNewDeployment=True
                    )
                    
                    deployment_results.append({
                        "service": service["serviceName"],
                        "status": "deployment_initiated",
                        "deployment_id": response["service"]["deployments"][0]["id"]
                    })
                    
                except Exception as e:
                    deployment_results.append({
                        "service": service["serviceName"],
                        "status": "failed",
                        "error": str(e)
                    })
            
            # Format response
            successful_deployments = [r for r in deployment_results if r["status"] == "deployment_initiated"]
            failed_deployments = [r for r in deployment_results if r["status"] == "failed"]
            
            response_text = f"""
ECS Force Deployment Results:

Cluster: {cluster_name}
Service Pattern: {service_name}-{environment}
Color Filter: {color if color else 'all colors'}

✅ Successful Deployments ({len(successful_deployments)}):
"""
            
            for result in successful_deployments:
                response_text += f"  - {result['service']}: Deployment {result['deployment_id']}\n"
            
            if failed_deployments:
                response_text += f"\n❌ Failed Deployments ({len(failed_deployments)}):\n"
                for result in failed_deployments:
                    response_text += f"  - {result['service']}: {result['error']}\n"
            
            response_text += f"\nTotal Services Processed: {len(deployment_results)}"
            
            return {
                "success": True,
                "response": response_text.strip(),
                "data": {
                    "cluster": cluster_name,
                    "successful_deployments": successful_deployments,
                    "failed_deployments": failed_deployments,
                    "total_services": len(deployment_results)
                }
            }
            
        except Exception as e:
            logger.error(f"Force deployment error: {e}")
            return {
                "success": False,
                "response": f"Error during force deployment: {str(e)}",
                "error": str(e)
            }
    
    async def _find_matching_services(self, cluster_name: str, service_name: str, environment: str, color: Optional[str] = None) -> List[Dict[str, Any]]:
        """Find services matching the pattern"""
        try:
            # List all services in the cluster
            paginator = self.ecs_client.get_paginator('list_services')
            all_services = []
            
            for page in paginator.paginate(cluster=cluster_name):
                service_arns = page['serviceArns']
                
                if service_arns:
                    # Get service details
                    services_response = self.ecs_client.describe_services(
                        cluster=cluster_name,
                        services=service_arns
                    )
                    all_services.extend(services_response['services'])
            
            # Filter services based on naming pattern
            matching_services = []
            
            for service in all_services:
                service_full_name = service['serviceName']
                
                # Expected pattern: <service-name>-<tier>-<color>-<random-chars>
                if self._matches_service_pattern(service_full_name, service_name, environment, color):
                    matching_services.append(service)
            
            return matching_services
            
        except Exception as e:
            logger.error(f"Error finding services: {e}")
            return []
    
    def _matches_service_pattern(self, full_service_name: str, service_name: str, environment: str, color: Optional[str] = None) -> bool:
        """Check if service name matches the expected pattern"""
        
        # Pattern: <service-name>-<tier>-<color>-<random-chars>
        # Example: commercehub-redis-buddy-dev-blue-abc123
        
        # Basic pattern check
        if not full_service_name.startswith(service_name):
            return False
        
        # Split the service name
        parts = full_service_name.split('-')
        
        if len(parts) < 4:  # Minimum: service-name-tier-color
            return False
        
        # Find environment in the parts
        if environment not in parts:
            return False
        
        # If color is specified, check for it
        if color:
            if color not in parts:
                return False
        
        # Additional validation: ensure it follows the expected pattern
        # Look for the pattern after service name
        remaining_name = full_service_name[len(service_name):].lstrip('-')
        
        # Should start with environment
        if not remaining_name.startswith(environment):
            return False
        
        return True
    
    async def _list_services(self, environment: str, service_pattern: Optional[str] = None) -> Dict[str, Any]:
        """List services in an environment"""
        try:
            if environment not in self.cluster_mapping:
                return {
                    "success": False,
                    "response": f"Invalid environment '{environment}'",
                    "error": "invalid_environment"
                }
            
            cluster_name = self.cluster_mapping[environment]
            
            # Get all services
            paginator = self.ecs_client.get_paginator('list_services')
            all_services = []
            
            for page in paginator.paginate(cluster=cluster_name):
                service_arns = page['serviceArns']
                
                if service_arns:
                    services_response = self.ecs_client.describe_services(
                        cluster=cluster_name,
                        services=service_arns
                    )
                    all_services.extend(services_response['services'])
            
            # Filter by pattern if provided
            if service_pattern:
                filtered_services = [
                    s for s in all_services 
                    if service_pattern.lower() in s['serviceName'].lower()
                ]
            else:
                filtered_services = all_services
            
            # Format response
            service_list = []
            for service in filtered_services:
                service_info = {
                    "name": service['serviceName'],
                    "status": service['status'],
                    "running_count": service['runningCount'],
                    "desired_count": service['desiredCount'],
                    "pending_count": service['pendingCount']
                }
                service_list.append(service_info)
            
            response_text = f"Services in {cluster_name}:\n\n"
            for service in service_list:
                response_text += f"• {service['name']}\n"
                response_text += f"  Status: {service['status']}\n"
                response_text += f"  Tasks: {service['running_count']}/{service['desired_count']} running\n\n"
            
            return {
                "success": True,
                "response": response_text.strip(),
                "data": {
                    "cluster": cluster_name,
                    "services": service_list,
                    "total_count": len(service_list)
                }
            }
            
        except Exception as e:
            logger.error(f"List services error: {e}")
            return {
                "success": False,
                "response": f"Error listing services: {str(e)}",
                "error": str(e)
            }
    
    async def _get_service_status(self, service_name: str, environment: str) -> Dict[str, Any]:
        """Get detailed status of a specific service"""
        try:
            cluster_name = self.cluster_mapping.get(environment)
            if not cluster_name:
                return {
                    "success": False,
                    "response": f"Invalid environment '{environment}'",
                    "error": "invalid_environment"
                }
            
            # Get service details
            response = self.ecs_client.describe_services(
                cluster=cluster_name,
                services=[service_name]
            )
            
            if not response['services']:
                return {
                    "success": False,
                    "response": f"Service '{service_name}' not found in cluster '{cluster_name}'",
                    "error": "service_not_found"
                }
            
            service = response['services'][0]
            
            # Format detailed status
            status_text = f"""
Service Status: {service['serviceName']}

Cluster: {cluster_name}
Status: {service['status']}
Task Definition: {service['taskDefinition'].split('/')[-1]}

Task Counts:
- Running: {service['runningCount']}
- Desired: {service['desiredCount']}
- Pending: {service['pendingCount']}

Recent Deployments:
"""
            
            for i, deployment in enumerate(service['deployments'][:3]):  # Show last 3 deployments
                status_text += f"  {i+1}. {deployment['status']} - {deployment['createdAt']}\n"
            
            return {
                "success": True,
                "response": status_text.strip(),
                "data": {
                    "service": service,
                    "cluster": cluster_name
                }
            }
            
        except Exception as e:
            logger.error(f"Get service status error: {e}")
            return {
                "success": False,
                "response": f"Error getting service status: {str(e)}",
                "error": str(e)
            }

# Lambda handler function
def lambda_handler(event, context):
    """AWS Lambda handler for ECS deployment worker"""
    try:
        worker = ECSDeploymentWorker()
        
        # Extract parameters from event
        action = event.get('action', 'force_deployment')
        kwargs = {k: v for k, v in event.items() if k != 'action'}
        
        # Execute action (note: this is sync in Lambda)
        import asyncio
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        
        try:
            result = loop.run_until_complete(worker.execute(action, **kwargs))
        finally:
            loop.close()
        
        return {
            'statusCode': 200,
            'body': json.dumps(result)
        }
        
    except Exception as e:
        logger.error(f"Lambda handler error: {e}")
        return {
            'statusCode': 500,
            'body': json.dumps({
                'success': False,
                'error': str(e)
            })
        }