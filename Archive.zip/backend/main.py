"""
DevOps Chatbot Backend - FastAPI MVP
Minimal backend with AWS Secrets Manager and AI Gateway authentication
"""

from fastapi import FastAPI, HTTPException, Depends
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import httpx
import jwt
import os
from datetime import datetime, timedelta
from typing import Optional
import logging
from secrets_loader import load_secrets_to_environment
from agents.agent_manager import AgentManager

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Load secrets from AWS into environment variables
try:
    logger.info("Loading secrets from AWS Secrets Manager...")
    load_secrets_to_environment()
    logger.info("Secrets loaded successfully")
except Exception as e:
    logger.warning(f"Failed to load secrets from AWS: {e}")
    logger.info("Continuing with existing environment variables...")

# Initialize Agent Manager with LangChain Supervisor
agent_manager = AgentManager()
logger.info("Agent Manager initialized with LangChain supervisor and advanced capabilities")

# FastAPI app
app = FastAPI(
    title="DevOps Chatbot Backend",
    description="Minimal backend for DevOps Chatbot with dual authentication",
    version="1.0.0"
)

# CORS middleware for frontend integration
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:8501", "http://127.0.0.1:8501"],  # Streamlit default ports
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Configuration from environment variables (loaded from AWS Secrets Manager)
JWT_SECRET = os.getenv("JWT_SECRET", "fallback-secret-key")
GATEWAY_URL = os.getenv("GATEWAY_URL", "https://your-ai-gateway.com/api/validate")
API_KEY = os.getenv("API_KEY", "")
API_SECRET = os.getenv("API_SECRET", "")
AGENT_USERNAME = os.getenv("AGENT_USERNAME", "")
AGENT_PASSWORD = os.getenv("AGENT_PASSWORD", "")
AI_GATEWAY_URL = os.getenv("AI_GATEWAY_URL", "https://connect-wan.fiservapis.com/ai/gateway/v1")

# Pydantic models
class LoginRequest(BaseModel):
    username: str
    password: str

class APILoginRequest(BaseModel):
    api_key: str
    api_secret: str

class AuthResponse(BaseModel):
    success: bool
    token: Optional[str] = None
    message: str
    user_info: Optional[dict] = None

class ChatMessage(BaseModel):
    message: str
    token: str

class ChatResponse(BaseModel):
    response: str
    success: bool

# Authentication functions
async def validate_aws_credentials(username: str, password: str) -> bool:
    """Validate username/password against environment variables loaded from AWS secret"""
    try:
        logger.info("Validating credentials against environment variables...")
        
        # Check if required environment variables are set
        if not AGENT_USERNAME or not AGENT_PASSWORD:
            logger.error("AGENT_USERNAME or AGENT_PASSWORD not set in environment")
            return False
        
        # Compare user-entered credentials with environment variables
        if AGENT_USERNAME == username and AGENT_PASSWORD == password:
            logger.info(f"Authentication successful for user: {username}")
            return True
        else:
            logger.info("Authentication failed - credentials do not match")
            return False
        
    except Exception as e:
        logger.error(f"AWS Secrets Manager validation error: {e}")
        return False

async def validate_ai_gateway_credentials(api_key: str, api_secret: str) -> bool:
    """Validate API key/secret against AI Gateway using environment variables"""
    try:
        # First check if the provided credentials match the ones from the secret
        if API_KEY and API_SECRET:
            if api_key == API_KEY and api_secret == API_SECRET:
                logger.info("API credentials match environment variables")
                
                # If we have a gateway URL, test it
                if GATEWAY_URL and GATEWAY_URL != "https://your-ai-gateway.com/api/validate":
                    async with httpx.AsyncClient() as client:
                        # Test prompt to validate credentials with the gateway
                        test_payload = {
                            "api_key": api_key,
                            "api_secret": api_secret,
                            "prompt": "Hello, validate my credentials",
                            "test": True
                        }
                        
                        response = await client.post(
                            GATEWAY_URL,
                            json=test_payload,
                            timeout=30.0
                        )
                        
                        if response.status_code == 200:
                            result = response.json()
                            # Check if the response indicates successful validation
                            return result.get('success', False) or result.get('valid', False)
                        
                        logger.warning(f"AI Gateway returned status {response.status_code}")
                        return False
                else:
                    # No gateway URL configured, just validate against environment variables
                    logger.info("No AI Gateway URL configured, validating against environment variables only")
                    return True
            else:
                logger.info("API credentials do not match environment variables")
                return False
        else:
            logger.error("API_KEY or API_SECRET not set in environment")
            # Fallback for MVP testing
            logger.warning("Using fallback validation for MVP")
            return api_key == "demo_api_key" and api_secret == "demo_secret"
            
    except Exception as e:
        logger.error(f"AI Gateway validation error: {e}")
        return False

def create_jwt_token(user_info: dict) -> str:
    """Create JWT token for session management"""
    payload = {
        "user_info": user_info,
        "exp": datetime.utcnow() + timedelta(hours=24),
        "iat": datetime.utcnow()
    }
    return jwt.encode(payload, JWT_SECRET, algorithm="HS256")

def verify_jwt_token(token: str) -> Optional[dict]:
    """Verify JWT token and return user info"""
    try:
        payload = jwt.decode(token, JWT_SECRET, algorithms=["HS256"])
        return payload.get("user_info")
    except jwt.ExpiredSignatureError:
        return None
    except jwt.InvalidTokenError:
        return None

# API Endpoints
@app.get("/")
async def root():
    return {"message": "DevOps Chatbot Backend API", "status": "running"}

@app.get("/health")
async def health_check():
    return {"status": "healthy", "timestamp": datetime.utcnow()}

@app.post("/api/v1/auth/login", response_model=AuthResponse)
async def login_username_password(request: LoginRequest):
    """Authenticate with username/password via AWS Secrets Manager"""
    try:
        is_valid = await validate_aws_credentials(request.username, request.password)
        
        if is_valid:
            user_info = {
                "username": request.username,
                "auth_method": "username_password",
                "login_time": datetime.utcnow().isoformat()
            }
            token = create_jwt_token(user_info)
            
            return AuthResponse(
                success=True,
                token=token,
                message="Login successful",
                user_info=user_info
            )
        else:
            raise HTTPException(
                status_code=401, 
                detail="Invalid username or password"
            )
            
    except Exception as e:
        logger.error(f"Login error: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

@app.post("/api/v1/auth/api-login", response_model=AuthResponse)
async def login_api_credentials(request: APILoginRequest):
    """Authenticate with API key/secret via AI Gateway"""
    try:
        is_valid = await validate_ai_gateway_credentials(request.api_key, request.api_secret)
        
        if is_valid:
            user_info = {
                "username": f"API User ({request.api_key[:8]}...)",
                "auth_method": "api_key",
                "login_time": datetime.utcnow().isoformat()
            }
            token = create_jwt_token(user_info)
            
            return AuthResponse(
                success=True,
                token=token,
                message="API login successful",
                user_info=user_info
            )
        else:
            raise HTTPException(
                status_code=401, 
                detail="Invalid API key or secret"
            )
            
    except Exception as e:
        logger.error(f"API login error: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

@app.post("/api/v1/chat/message", response_model=ChatResponse)
async def send_message(request: ChatMessage):
    """Send message to DevOps Chatbot via Agent System"""
    try:
        # Verify token
        user_info = verify_jwt_token(request.token)
        if not user_info:
            raise HTTPException(status_code=401, detail="Invalid or expired token")
        
        # Prepare context for agents
        context = {
            "user_info": user_info,
            "timestamp": datetime.utcnow().isoformat(),
            "session_token": request.token
        }
        
        # Process message through agent system
        agent_result = await agent_manager.process_message(request.message, context)
        
        if agent_result.get("success", True):
            return ChatResponse(
                response=agent_result.get("response", "No response generated"),
                success=True
            )
        else:
            # Agent system returned an error, but we still want to return a response
            return ChatResponse(
                response=agent_result.get("response", "I encountered an error processing your request"),
                success=True  # We still return success to the frontend
            )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Chat error: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

@app.post("/api/v1/auth/validate")
async def validate_token(token: str):
    """Validate JWT token"""
    user_info = verify_jwt_token(token)
    if user_info:
        return {"valid": True, "user_info": user_info}
    else:
        return {"valid": False}

@app.get("/api/v1/agents/status")
async def get_agent_status():
    """Get the status of all agents in the system"""
    try:
        status = await agent_manager.get_system_status()
        return {"success": True, "status": status}
    except Exception as e:
        logger.error(f"Error getting agent status: {e}")
        return {"success": False, "error": str(e)}

@app.get("/api/v1/agents/list")
async def list_agents():
    """List all available agents"""
    try:
        agents = agent_manager.get_available_agents()
        return {"success": True, "agents": agents}
    except Exception as e:
        logger.error(f"Error listing agents: {e}")
        return {"success": False, "error": str(e)}

@app.get("/api/v1/memory/stats")
async def get_memory_stats():
    """Get conversation memory statistics"""
    try:
        stats = await agent_manager.get_memory_stats()
        return {"success": True, "memory_stats": stats}
    except Exception as e:
        logger.error(f"Error getting memory stats: {e}")
        return {"success": False, "error": str(e)}

@app.delete("/api/v1/memory/user/{user_id}")
async def clear_user_memory(user_id: str):
    """Clear conversation memory for a specific user"""
    try:
        result = await agent_manager.clear_user_memory(user_id)
        return result
    except Exception as e:
        logger.error(f"Error clearing user memory: {e}")
        return {"success": False, "error": str(e)}

@app.get("/api/v1/system/health")
async def system_health():
    """Comprehensive system health check"""
    try:
        # Get agent system status
        agent_status = await agent_manager.get_system_status()
        
        # Get memory stats
        memory_stats = await agent_manager.get_memory_stats()
        
        # Check Lambda configuration
        lambda_config = {
            "aws_secrets_function": os.getenv("AWS_SECRETS_LAMBDA_FUNCTION", "aws-secrets-agent"),
            "ecs_deploy_function": os.getenv("ECS_DEPLOY_LAMBDA_FUNCTION", "ecs-deploy-agent")
        }
        
        # Basic health indicators
        health_status = {
            "status": "healthy",
            "timestamp": datetime.utcnow().isoformat(),
            "agent_system": agent_status,
            "memory_system": memory_stats,
            "lambda_config": lambda_config,
            "features": {
                "conversation_memory": memory_stats.get("status") == "active",
                "error_recovery": True,
                "multi_agent_workflows": True,
                "langchain_integration": True,
                "lambda_workers": True
            }
        }
        
        return {"success": True, "health": health_status}
        
    except Exception as e:
        logger.error(f"Error in health check: {e}")
        return {
            "success": False, 
            "status": "unhealthy",
            "error": str(e),
            "timestamp": datetime.utcnow().isoformat()
        }

@app.get("/api/v1/lambda/config")
async def get_lambda_config():
    """Get Lambda function configuration"""
    try:
        config = {
            "aws_secrets_function": os.getenv("AWS_SECRETS_LAMBDA_FUNCTION", "aws-secrets-agent"),
            "ecs_deploy_function": os.getenv("ECS_DEPLOY_LAMBDA_FUNCTION", "ecs-deploy-agent"),
            "region": os.getenv("AWS_REGION", "us-east-1")
        }
        
        return {"success": True, "lambda_config": config}
        
    except Exception as e:
        logger.error(f"Error getting Lambda config: {e}")
        return {"success": False, "error": str(e)}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)